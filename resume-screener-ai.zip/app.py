import streamlit as st
import pdfplumber
from sentence_transformers import SentenceTransformer, util

# Load BERT model
model = SentenceTransformer('all-MiniLM-L6-v2')

def extract_text_from_pdf(uploaded_file):
    with pdfplumber.open(uploaded_file) as pdf:
        return "\n".join(page.extract_text() for page in pdf.pages if page.extract_text())

def rank_resumes(job_desc, resume_texts):
    job_embedding = model.encode(job_desc, convert_to_tensor=True)
    resume_embeddings = model.encode(resume_texts, convert_to_tensor=True)
    similarities = util.cos_sim(job_embedding, resume_embeddings)[0]
    return sorted(zip(resume_texts, similarities), key=lambda x: x[1], reverse=True)

# Streamlit App
st.set_page_config(page_title="AI Resume Screener", layout="wide")
st.title("🤖 AI Resume Screener")
st.markdown("Upload resumes (PDF) and paste a job description. Get AI-ranked candidates based on semantic similarity.")

job_description = st.text_area("Paste the Job Description here", height=250)
uploaded_files = st.file_uploader("Upload Resume PDFs", type="pdf", accept_multiple_files=True)

if st.button("🚀 Rank Resumes"):
    if not job_description or not uploaded_files:
        st.warning("Please upload at least one resume and enter a job description.")
    else:
        with st.spinner("Processing..."):
            resume_texts = []
            for file in uploaded_files:
                try:
                    text = extract_text_from_pdf(file)
                    resume_texts.append(text)
                except Exception as e:
                    st.error(f"Error reading {file.name}: {e}")

            if resume_texts:
                ranked = rank_resumes(job_description, resume_texts)
                st.success("✅ Resumes ranked successfully!")

                for i, (text, score) in enumerate(ranked):
                    st.markdown(f"### Rank {i+1} - Score: {score:.2f}")
                    st.text_area("Preview", text[:1000], height=200)
                    st.markdown("---")
            else:
                st.error("Could not process any resumes.")
