# 🤖 AI Resume Screener

An AI-powered app to rank resumes based on how well they match a job description using BERT embeddings.

## 🔍 Features

- Upload multiple resumes (PDFs)
- Paste a job description
- Uses semantic similarity to rank resumes
- Interactive UI with Streamlit

## 🚀 Demo

[Insert Hugging Face Spaces or Render link here if deployed]

## 🛠️ Tech Stack

- Python
- Streamlit
- Sentence Transformers (`all-MiniLM-L6-v2`)
- pdfplumber

## 🧪 How to Run

1. Clone the repo:

```bash
git clone https://github.com/yourusername/resume-screener-ai.git
cd resume-screener-ai
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run the app:

```bash
streamlit run app.py
```

## 📄 Sample Resumes

You can place a few sample PDF resumes in the `/sample_resumes` folder to test.

## 📬 Contact

Made by [Your Name]. Feel free to fork and build on it!
